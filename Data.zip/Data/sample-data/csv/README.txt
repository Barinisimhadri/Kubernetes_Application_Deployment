userdata[1-5].csv: These are sample files containing data in csv format.

- Each file has a header
- Number of data rows in each file: 1000
