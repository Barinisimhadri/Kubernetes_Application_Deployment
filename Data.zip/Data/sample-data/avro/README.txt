userdata[1-5].avro: These are sample files containing data in AVRO format. The schema is in userdata.avsc file.
userdata1.avro: 1000 records
userdata2.avro: 998 records
userdata3.avro: 1000 records
userdata4.avro: 1000 records
userdata5.avro: 1000 records
